import { Category, InsertCategory, Video, InsertVideo } from "@shared/schema";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  searchCategories(query: string): Promise<Category[]>;

  // Videos
  getVideos(categoryId: number): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  searchVideos(query: string): Promise<Video[]>;
}

export class MemStorage implements IStorage {
  private categories: Map<number, Category>;
  private videos: Map<number, Video>;
  private currentCategoryId: number;
  private currentVideoId: number;

  constructor() {
    this.categories = new Map();
    this.videos = new Map();
    this.currentCategoryId = 1;
    this.currentVideoId = 1;

    // Add initial categories
    this.createCategory({
      name: "Solo Leveling",
      posterUrl: "https://picsum.photos/800/400?random=1"
    });
    this.createCategory({
      name: "Hero Academia",
      posterUrl: "https://picsum.photos/800/400?random=2"
    });
    this.createCategory({
      name: "Attack on Titan",
      posterUrl: "https://picsum.photos/800/400?random=3"
    });
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const newCategory = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  async searchCategories(query: string): Promise<Category[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.categories.values()).filter((category) =>
      category.name.toLowerCase().includes(lowercaseQuery)
    );
  }

  async getVideos(categoryId: number): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(
      (video) => video.categoryId === categoryId
    );
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const id = this.currentVideoId++;
    const newVideo = { ...video, id };
    this.videos.set(id, newVideo);
    return newVideo;
  }

  async searchVideos(query: string): Promise<Video[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.videos.values()).filter((video) =>
      video.title.toLowerCase().includes(lowercaseQuery)
    );
  }
}

export const storage = new MemStorage();