import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertVideoSchema, insertCategorySchema } from "@shared/schema";
import express from "express";

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir)
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, uniqueSuffix + path.extname(file.originalname))
  }
});

const upload = multer({
  storage: storage_config,
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB limit
});

export async function registerRoutes(app: Express) {
  // Serve static files from uploads directory
  app.use('/uploads', express.static(uploadsDir));

  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.get("/api/categories/search", async (req, res) => {
    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ error: "Search query required" });
    }
    const categories = await storage.searchCategories(query);
    res.json(categories);
  });

  app.post("/api/categories", async (req, res) => {
    const result = insertCategorySchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const category = await storage.createCategory(result.data);
    res.json(category);
  });

  // Videos
  app.get("/api/videos/:categoryId", async (req, res) => {
    const categoryId = parseInt(req.params.categoryId);
    if (isNaN(categoryId)) {
      return res.status(400).json({ error: "Invalid category ID" });
    }
    const videos = await storage.getVideos(categoryId);
    res.json(videos);
  });

  app.post("/api/videos", upload.fields([
    { name: 'video', maxCount: 1 },
    { name: 'thumbnail', maxCount: 1 }
  ]), async (req, res) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };

      if (!files.video || !files.thumbnail) {
        return res.status(400).json({ error: "Video and thumbnail files are required" });
      }

      // Use the actual saved filenames for URLs
      const videoUrl = `/uploads/${files.video[0].filename}`;
      const thumbnailUrl = `/uploads/${files.thumbnail[0].filename}`;

      const data = {
        ...req.body,
        videoUrl,
        thumbnailUrl,
        categoryId: parseInt(req.body.categoryId),
        qualities: JSON.parse(req.body.qualities)
      };

      const result = insertVideoSchema.safeParse(data);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      const video = await storage.createVideo(result.data);
      res.json(video);
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: "Failed to upload video" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}