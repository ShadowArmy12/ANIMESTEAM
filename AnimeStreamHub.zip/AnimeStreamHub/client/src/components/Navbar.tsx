import { SearchBar } from './SearchBar';
import { useLocation } from 'wouter';
import { type Category } from '@shared/schema';

interface NavbarProps {
  onSearch: (results: Category[]) => void;
}

export function Navbar({ onSearch }: NavbarProps) {
  const [, setLocation] = useLocation();

  const handleSearch = async (query: string) => {
    try {
      if (!query.trim()) {
        onSearch([]);
        return;
      }

      const response = await fetch(`/api/categories/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error('Search failed');
      const categories = await response.json();
      onSearch(categories);
    } catch (error) {
      console.error('Search error:', error);
      onSearch([]);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b">
      <div className="container flex items-center justify-between h-16 px-4">
        <h1 className="text-xl font-bold">Anime Stream</h1>
        <div className="flex-1 mx-4">
          <SearchBar onSearch={handleSearch} />
        </div>
        <button 
          onClick={() => setLocation('/admin')}
          className="text-sm text-muted-foreground hover:text-primary"
        >
          Admin
        </button>
      </div>
    </nav>
  );
}
