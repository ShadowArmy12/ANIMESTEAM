import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Video } from '@shared/schema';
import { VideoPlayer } from './ui/video-player';
import { X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

interface CategorySlideProps {
  title: string;
  videos: Video[];
  isOpen: boolean;
  onClose: () => void;
}

export function CategorySlide({ title, videos, isOpen, onClose }: CategorySlideProps) {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 20 }}
          className="fixed inset-0 bg-background z-50 overflow-y-auto"
        >
          <div className="p-4 md:p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl md:text-2xl font-bold">{title}</h2>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-5 w-5 md:h-6 md:w-6" />
              </Button>
            </div>

            {selectedVideo ? (
              <div className="mb-6">
                <VideoPlayer
                  url={selectedVideo.videoUrl}
                  qualities={selectedVideo.qualities}
                  onQualityChange={(quality) => console.log('Quality changed:', quality)}
                  onDownload={() => console.log('Download clicked')}
                />
                <Button 
                  variant="outline" 
                  className="mt-4 w-full md:w-auto"
                  onClick={() => setSelectedVideo(null)}
                >
                  Back to Videos
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {videos.map((video) => (
                  <Card 
                    key={video.id}
                    className="cursor-pointer hover:scale-105 transition-transform"
                    onClick={() => setSelectedVideo(video)}
                  >
                    <CardContent className="p-0">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full aspect-video object-cover rounded-t-lg"
                        loading="lazy"
                      />
                      <div className="p-3 md:p-4">
                        <h3 className="font-semibold text-sm md:text-base">{video.title}</h3>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}