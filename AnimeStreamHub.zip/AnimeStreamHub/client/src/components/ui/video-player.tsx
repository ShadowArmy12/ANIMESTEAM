import React from 'react';
import ReactPlayer from 'react-player';
import { Button } from './button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';
import { Download } from 'lucide-react';

interface VideoPlayerProps {
  url: string;
  qualities: string[];
  onQualityChange: (quality: string) => void;
  onDownload: () => void;
}

export function VideoPlayer({ url, qualities, onQualityChange, onDownload }: VideoPlayerProps) {
  return (
    <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
      <ReactPlayer
        url={url}
        width="100%"
        height="100%"
        controls
        playing
        config={{
          file: {
            attributes: {
              controlsList: 'nodownload'
            }
          }
        }}
      />
      <div className="absolute bottom-4 right-4 flex gap-2">
        <Select onValueChange={onQualityChange}>
          <SelectTrigger className="w-[100px] bg-black/70">
            <SelectValue placeholder="Quality" />
          </SelectTrigger>
          <SelectContent>
            {qualities.map((quality) => (
              <SelectItem key={quality} value={quality}>
                {quality}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={onDownload}>
          <Download className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
