import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Category, Video } from '@shared/schema';
import { Navbar } from '@/components/Navbar';
import { CategorySlide } from '@/components/CategorySlide';
import { Card, CardContent } from '@/components/ui/card';

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [filteredCategories, setFilteredCategories] = useState<Category[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories']
  });

  const { data: videos = [] } = useQuery<Video[]>({
    queryKey: ['/api/videos', selectedCategory?.id],
    enabled: !!selectedCategory
  });

  const displayCategories = isSearching ? filteredCategories : categories;

  const handleSearch = (results: Category[]) => {
    setFilteredCategories(results);
    setIsSearching(results.length > 0);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar onSearch={handleSearch} />

      <main className="container pt-24 pb-16 px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {displayCategories.map((category) => (
            <Card 
              key={category.id}
              className="cursor-pointer hover:scale-105 transition-transform"
              onClick={() => setSelectedCategory(category)}
            >
              <CardContent className="p-0">
                <div className="relative aspect-[2/1]">
                  <img
                    src={category.posterUrl}
                    alt={category.name}
                    className="w-full h-full object-cover rounded-t-lg"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <h2 className="absolute bottom-4 left-4 text-lg md:text-xl font-bold text-white">
                    {category.name}
                  </h2>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      <CategorySlide
        title={selectedCategory?.name || ''}
        videos={videos}
        isOpen={!!selectedCategory}
        onClose={() => setSelectedCategory(null)}
      />
    </div>
  );
}