import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  posterUrl: text("poster_url").notNull(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  videoUrl: text("video_url").notNull(),
  categoryId: integer("category_id").notNull(),
  qualities: text("qualities").array().notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  posterUrl: true,
});

export const insertVideoSchema = createInsertSchema(videos).pick({
  title: true,
  thumbnailUrl: true,
  videoUrl: true,
  categoryId: true,
  qualities: true,
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
